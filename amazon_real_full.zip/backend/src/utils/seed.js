const mongoose = require('mongoose');
const dotenv = require('dotenv');
dotenv.config();
const User = require('../models/user.model');
const Product = require('../models/product.model');
const bcrypt = require('bcrypt');

async function runSeed(){
  try{
    await mongoose.connect(process.env.MONGO_URI);
    console.log('Connected for seeding');
    const adminEmail = 'admin@demo.com';
    const existing = await User.findOne({ email: adminEmail });
    if (!existing){
      const hash = await bcrypt.hash('Password123', 10);
      await User.create({ name: 'Demo Admin', email: adminEmail, passwordHash: hash, role: 'admin' });
      console.log('Admin created:', adminEmail, 'Password123');
    } else console.log('Admin exists');
    const sample = [
      { title: "Smart LED TV 43\"", price:27999, category:'Electronics', images:['https://images.unsplash.com/photo-1580910051071-9f58f6b8f7a6?auto=format&fit=crop&w=800&q=60'], stock:20 },
      { title: "Men's Running Shoes", price:2499, category:'Footwear', images:['https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=800&q=60'], stock:50 },
      { title: "Wireless Earbuds", price:2999, category:'Electronics', images:['https://images.unsplash.com/photo-1593642634367-d91a135587b5?auto=format&fit=crop&w=800&q=60'], stock:120 }
    ];
    for (const p of sample){
      const exists = await Product.findOne({ title: p.title });
      if (!exists) await Product.create(p);
    }
    console.log('Products seeded');
    await mongoose.disconnect();
  }catch(err){ console.error('Seed error', err); }
}

module.exports = { runSeed };
