const mongoose = require('mongoose');
const { Schema } = mongoose;
const productSchema = new Schema({
  title: String, description: String, price: Number, category: String,
  images: [String], stock: { type: Number, default: 0 },
  sellerId: { type: Schema.Types.ObjectId, ref: 'User' },
  rating: { type: Number, default: 0 }, createdAt: { type: Date, default: Date.now }
});
productSchema.index({ title: 'text', category: 'text' });
module.exports = mongoose.model('Product', productSchema);
