const mongoose = require('mongoose');
const { Schema } = mongoose;
const orderSchema = new Schema({
  user: { type: Schema.Types.ObjectId, ref: 'User' },
  items: [{ product: { type: Schema.Types.ObjectId, ref: 'Product' }, qty: Number, price: Number }],
  total: Number, status: { type: String, default: 'created' }, shippingAddress: String,
  paymentInfo: Object, createdAt: { type: Date, default: Date.now }
});
module.exports = mongoose.model('Order', orderSchema);
