const Order = require('../models/order.model');
const Product = require('../models/product.model');

exports.createOrder = async (req, res) => {
  const { items, total, shippingAddress, userId } = req.body;
  // Basic validation
  if (!items || !items.length) return res.status(400).json({ message: 'No items' });
  // Create order
  const order = await Order.create({ items, total, shippingAddress, user: userId });
  res.json({ order });
};

exports.listOrders = async (req, res) => {
  const orders = await Order.find().populate('user').limit(200);
  res.json({ orders });
};
