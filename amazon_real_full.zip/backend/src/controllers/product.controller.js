const Product = require('../models/product.model');

exports.listProducts = async (req, res) => {
  const { q, category } = req.query;
  const filter = {};
  if (q) filter.$text = { $search: q };
  if (category && category !== 'All') filter.category = category;
  const products = await Product.find(filter).limit(100);
  res.json({ products });
};

exports.getProduct = async (req, res) => {
  const p = await Product.findById(req.params.id);
  if (!p) return res.status(404).json({ message: 'Not found' });
  res.json(p);
};

exports.createProduct = async (req, res) => {
  const body = req.body;
  const p = await Product.create(body);
  res.json(p);
};
