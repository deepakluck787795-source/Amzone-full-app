const express = require('express');
const router = express.Router();
const { createOrder, listOrders } = require('../controllers/order.controller');
router.post('/', createOrder);
router.get('/', listOrders); // admin
module.exports = router;
