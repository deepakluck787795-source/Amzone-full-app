const express = require('express');
const router = express.Router();
const { listProducts, getProduct, createProduct } = require('../controllers/product.controller');
router.get('/', listProducts);
router.get('/:id', getProduct);
router.post('/', createProduct); // admin/seller protected ideally
module.exports = router;
