Amazon-Style Full Starter (Next.js + Express + MongoDB)
=====================================================

This repository is a starter scaffold for a production-capable Amazon-style marketplace.
It includes:
- Frontend: Next.js (pages: index, product, cart, auth, admin dashboard)
- Backend: Express + Mongoose (models: User, Product, Order) with JWT auth
- Seed script to create demo admin and products
- Docker & docker-compose for local development
- .env.example for environment variables

IMPORTANT: This is a starter. Replace placeholder secrets, secure JWT, configure payment provider, and add production-grade security before deploying.

Quickstart (local):
1. Install Docker & Docker Compose
2. Copy .env.example to .env and fill values (MONGO_URI can be mongodb://mongo:27017/amazon)
3. Run: docker-compose up --build
4. Backend API will be at http://localhost:5000
5. Frontend dev server (Next.js) at http://localhost:3000 (the Docker setup runs both)

Seed demo data:
- The backend container runs seed on startup to create an admin user:
  admin@demo.com / Password123

