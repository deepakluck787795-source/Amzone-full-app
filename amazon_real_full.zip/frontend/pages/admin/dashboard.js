import React, { useEffect, useState } from 'react';
import axios from 'axios';
export default function AdminDashboard(){ 
  const [products, setProducts] = useState([]);
  useEffect(()=> axios.get(process.env.NEXT_PUBLIC_API_URL + '/products').then(r=>setProducts(r.data.products)).catch(()=>{}), []);
  return (<div className='container'><h1>Admin Dashboard</h1><div style={{marginTop:12}}>{products.map(p=>(<div key={p._id||p.id} style={{border:'1px solid #eee',padding:8,marginBottom:8}}><strong>{p.title}</strong> - ₹{p.price}</div>))}</div></div>);
}
