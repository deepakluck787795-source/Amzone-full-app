import React, { useEffect, useState } from 'react';
import axios from 'axios';
function currency(n){ return '₹' + n.toLocaleString('en-IN'); }
export default function Home(){ 
  const [products, setProducts] = useState([]);
  const [q, setQ] = useState('');
  useEffect(()=>{ axios.get(process.env.NEXT_PUBLIC_API_URL + '/products').then(r=>setProducts(r.data.products)).catch(()=>{}); },[]);
  return (
    <div className='container'>
      <div className='header'>
        <h1>Amazon-style Store</h1>
        <input className='search' placeholder='Search...' value={q} onChange={e=>setQ(e.target.value)} />
        <a href='/cart'><button className='btn'>Cart</button></a>
      </div>
      <div style={{marginTop:12}}><a href='/admin/dashboard'><button className='btn'>Admin Dashboard</button></a></div>
      <div className='grid'>
        {products.filter(p=> (p.title + ' ' + p.category).toLowerCase().includes(q.toLowerCase())).map(p=> (
          <div key={p._id || p.id} className='card'>
            <img src={p.images?.[0] || p.image} alt={p.title} />
            <div className='body'>
              <div style={{fontWeight:600}}>{p.title}</div>
              <div style={{marginTop:6,color:'#64748b'}}>{p.category} • ⭐ {p.rating}</div>
              <div style={{marginTop:'auto',display:'flex',justifyContent:'space-between',alignItems:'center'}}>
                <div style={{fontWeight:700}}>{currency(p.price)}</div>
                <div><a href={'/product/'+(p._id || p.id)}><button className='btn'>View</button></a></div>
              </div>
            </div>
          </div>
        ))}
      </div>
      <div className='footer'>Demo • Replace with real integrations before production</div>
    </div>
  );
}
