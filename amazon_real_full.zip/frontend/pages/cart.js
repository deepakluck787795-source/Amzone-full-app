import React, { useEffect, useState } from 'react';
import axios from 'axios';
function currency(n){ return '₹' + n.toLocaleString('en-IN'); }
export default function Cart(){ 
  const [cart, setCart] = useState([]);
  useEffect(()=> setCart(JSON.parse(localStorage.getItem('cart')||'[]')), []);
  async function place(){ 
    const name = prompt('Name','Demo');
    const address = prompt('Address','Somewhere');
    const res = await axios.post(process.env.NEXT_PUBLIC_API_URL + '/orders', { items: cart, total: cart.reduce((s,i)=>s + (i.price||0)*i.qty,0), name, address });
    alert('Order placed: ' + res.data.order._id || res.data.order.id);
    localStorage.removeItem('cart'); setCart([]);
  }
  return (<div className='container'><h2>Your Cart</h2>{cart.length===0 ? <div>Empty</div> : (<div><ul>{cart.map((c,i)=>(<li key={i}>{c.id} x {c.qty} - ₹{c.price}</li>))}</ul><button onClick={place} className='btn'>Place Order</button></div>)}</div>);
}
