import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useRouter } from 'next/router';
function currency(n){ return '₹' + n.toLocaleString('en-IN'); }
export default function ProductPage(){ 
  const r = useRouter(); const { id } = r.query;
  const [p, setP] = useState(null);
  useEffect(()=>{ if(!id) return; axios.get(process.env.NEXT_PUBLIC_API_URL + '/products/' + id).then(r=>setP(r.data)).catch(()=>{}); },[id]);
  if(!p) return <div className='container'>Loading...</div>;
  return (<div className='container'><h2>{p.title}</h2><img src={p.images?.[0]||p.image} style={{maxWidth:400}}/><p>{currency(p.price)}</p><button className='btn' onClick={()=>{ let cart=JSON.parse(localStorage.getItem('cart')||'[]'); cart.push({id:p._id||p.id, qty:1}); localStorage.setItem('cart', JSON.stringify(cart)); alert('Added (demo)'); }}>Add to cart</button></div>);
}
