Admin skeleton included in frontend under /admin route (Next.js page). Use that for admin dashboard.
